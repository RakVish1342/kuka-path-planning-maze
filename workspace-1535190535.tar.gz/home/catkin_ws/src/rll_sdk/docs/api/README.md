 
### RLL API Description

API description done with Swagger aka OpenAPI.

For more information about OpenAPI, see the [documentation](https://swagger.io/docs/specification/about/).

#### Development

In order to improve the API description, you can use the [online swagger editor](https://editor.swagger.io/).
Just copy and paste the openapi.yaml.

Its also possible to run your own editor in docker: 

	docker run -d -p 80:8080 swaggerapi/swagger-editor
	
See:
	https://github.com/swagger-api/swagger-editor

Also a nice tool for expanding the api-description:
	https://openapi-map.apihandyman.io/
